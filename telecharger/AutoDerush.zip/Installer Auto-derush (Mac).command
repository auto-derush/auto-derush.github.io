#!/bin/bash
# Installe Auto-dérush dans Premiere Pro (Mac). Fermez Premiere Pro avant de lancer.
# Premier lancement : clic droit sur ce fichier > Ouvrir (macOS bloque les scripts téléchargés).
cd "$(dirname "$0")" || exit 1
ZXP=$(ls AutoDerush-*.zxp 2>/dev/null | head -n 1)
if [ -z "$ZXP" ]; then
  echo "Fichier AutoDerush-....zxp introuvable a cote de cet installateur."
  read -r -p "Appuyez sur Entree pour fermer."
  exit 1
fi
DEST="$HOME/Library/Application Support/Adobe/CEP/extensions/com.william.autoderush"
echo "Installation d'Auto-derush..."
# Un lien (installation de developpement) est retire sans toucher a sa cible.
if [ -L "$DEST" ]; then rm "$DEST"; elif [ -d "$DEST" ]; then rm -rf "$DEST"; fi
mkdir -p "$DEST"
if ! unzip -q -o "$ZXP" -d "$DEST"; then
  echo "L'installation a echoue."
  read -r -p "Appuyez sur Entree pour fermer."
  exit 1
fi
# Fichiers telecharges : on retire la mise en quarantaine de macOS pour que Premiere charge le panneau.
xattr -dr com.apple.quarantine "$DEST" 2>/dev/null
echo
echo "Auto-derush est installe."
echo "Ouvrez Premiere Pro, puis : Fenetre > Extensions > Auto-derush"
echo "et collez la cle de licence recue par e-mail."
read -r -p "Appuyez sur Entree pour fermer."
