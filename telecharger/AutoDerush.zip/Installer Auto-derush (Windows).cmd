@echo off
chcp 65001 >nul
rem Installe Auto-dérush dans Premiere Pro (Windows). Fermez Premiere Pro avant de lancer.
setlocal
set "DEST=%APPDATA%\Adobe\CEP\extensions\com.william.autoderush"
set "ZXP="
for %%f in ("%~dp0AutoDerush-*.zxp") do set "ZXP=%%~ff"
if not defined ZXP (
  echo Fichier AutoDerush-....zxp introuvable a cote de cet installateur.
  pause & exit /b 1
)
echo Installation d'Auto-derush...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop';" ^
  "$tmp = Join-Path $env:TEMP 'autoderush-install.zip';" ^
  "Copy-Item -LiteralPath $env:ZXP -Destination $tmp -Force;" ^
  "if (Test-Path -LiteralPath $env:DEST) {" ^
  "  $old = Get-Item -LiteralPath $env:DEST -Force;" ^
  "  if ($old.Attributes -band [IO.FileAttributes]::ReparsePoint) { $old.Delete() } else { Remove-Item -LiteralPath $env:DEST -Recurse -Force }" ^
  "};" ^
  "Expand-Archive -LiteralPath $tmp -DestinationPath $env:DEST -Force;" ^
  "Remove-Item -LiteralPath $tmp -Force"
if errorlevel 1 (
  echo L'installation a echoue.
  pause & exit /b 1
)
echo.
echo Auto-derush est installe.
echo Ouvrez Premiere Pro, puis : Fenetre ^> Extensions ^> Auto-derush
echo et collez la cle de licence recue par e-mail.
pause
